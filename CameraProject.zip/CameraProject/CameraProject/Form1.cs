﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using DarrenLee.Media;
namespace CameraProject
{
    public partial class Form1 : Form
    {
        int count = 0;
        Camera mycamera = new Camera();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            mycamera.OnFrameArrived += Mycamera_OnFrameArrived;
        }

        private void Mycamera_OnFrameArrived(object source, FrameArrivedEventArgs e)
        {
            Image img = e.GetFrame();
            pictureBox1.Image = img;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mycamera.ChangeCamera(comboBox1.SelectedIndex);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\HASSAN MALIK\Desktop\CameraProject\" + "Image_Number" + count.ToString();
            mycamera.Capture(path);
            mycamera.Stop();
        }
    }
}
